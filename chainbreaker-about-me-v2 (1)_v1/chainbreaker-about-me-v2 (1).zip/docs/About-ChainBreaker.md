# GPT Setup Instructions (For ChatGPT Agent)

This file is the official `About-ChainBreaker.md`. When extracted into any project:

1. **Place this file** in `/docs/About-ChainBreaker.md`
2. **Reference this file** in:
   - /tech-backend for Gmail API and endpoint logic
   - /app-code-repository docs for frontend + summarizer modes
   - /launch-instructions and /marketing-strategy for GTM prep
3. **Use the "Integration Instructions"** section to trigger automation workflows
4. **Sync it across all system folders** as the canonical project explanation
5. **Ensure the file is named exactly:** `About-ChainBreaker.md`

Once confirmed, process the full document to align system functions and setup tasks.

---
# About Chain Breaker

Chain Breaker is an AI-powered Gmail summarization tool designed for professionals who deal with overwhelming, repetitive, or disorganized email chains. It helps users instantly extract the core information, eliminate noise, and act on what's important.

---

## What This File Is

This `About-ChainBreaker.md` file is the official project description and integration guide for the Chain Breaker tool. It is to be used across all supporting ChatGPT projects to ensure consistency and clarity in development, marketing, and automation workflows.

---

## Integration Instructions for Other Projects

### 1. **TogetherWe Automate**
- Store this Markdown file in the `/docs/projects/chainbreaker/` folder.
- Reference the "Core Modes" and "Why It Matters" sections in automation dashboards and form documentation.
- Connect to Zapier scripts that route email content summaries to Airtable or Slack.

### 2. **Tech_Backend**
- Sync this with the Gmail API handler logic and endpoint structure.
- Add the "Core Modes" section as in-code comments for future devs and function documentation.

### 3. **App_Code_Repository**
- Include the Markdown file under `/docs/About/` for this specific Gmail add-on repo.
- Use it as the README base for developers contributing to UI logic, error handling, or summarization engines.

### 4. **Launch Instructions**
- Add this file to the `/release-assets/` folder when packaging the app for the Google Workspace Marketplace.
- Extract copywriting for store listings and onboarding guides from this Markdown file.

---

## What Chain Breaker Does

Chain Breaker offers 3 summarization modes for Gmail email chains:

### Mode 1: Clean Email Body Extractor
- **Strips away** all signatures, headers, footers, and email address metadata
- **Returns only** the core message texts in order

### Mode 2: Full Email Chain Summary
- **Reads the full thread**
- **Outputs a paragraph summary** of the key discussion points and updates

### Mode 3: Action Item Extractor
- **Scans the thread for tasks**
- **Outputs a bulleted list** of follow-ups, deadlines, or decisions to make

---

## Key Features
- **Gmail Integration:** Seamless access via sidebar add-on
- **Three Summarization Modes:** Choose between raw body, short summary, or action list
- **Simple UI:** One-click operation for each mode
- **Secure & Fast:** Operates using Google APIs and OpenAI summarization tools

---

## Technical System
- **Gmail API:** Fetches email threads with secure OAuth access
- **OpenAI Models:** Used for summarization and action item detection
- **Google Workspace Add-on:** Lightweight frontend interface
- **Zapier/Make Support:** Optional automation with Notion, Airtable, or Slack

---

## Who It’s For
- **Executives** needing fast decisions without reading every email
- **Assistants** summarizing updates for teams
- **Lawyers, consultants, or sales teams** dealing with repetitive threads

---

## Why It Matters
Most professionals waste hours a week digging through email clutter. Chain Breaker gives them back that time—letting them get straight to the point, act faster, and stay focused on what really matters.

