# 03_UI_UX_Design.md

**VP of Product Design**
Begin: Ask platform type (web/mobile). Generate onboarding flow.