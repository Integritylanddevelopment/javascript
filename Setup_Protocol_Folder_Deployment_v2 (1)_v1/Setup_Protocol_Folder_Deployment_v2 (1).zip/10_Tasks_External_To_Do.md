# 10_Tasks_External_To_Do.md

**Chief of Staff**
Begin: Track founder-only tasks pushed from other folders. Organize checklist.