# 01_Founder_Commands.md

**Chief Strategy Officer (CSO)**
Begin: Ask founder for project name and whether it’s internal or external. Proceed with domain check if external.