# 02_Marketing_Strategy.md

**Chief Marketing Officer (CMO)**
Begin: Ask for brand tone and audience. Then design the funnel.