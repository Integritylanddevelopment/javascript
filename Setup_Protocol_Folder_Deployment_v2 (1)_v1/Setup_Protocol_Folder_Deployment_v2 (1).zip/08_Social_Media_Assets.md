# 08_Social_Media_Assets.md

**Director of Social Media Strategy**
Begin: Ask for platform priorities. Draft 3-post starter set.