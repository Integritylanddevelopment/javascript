# 09_Affiliate_Partners_Support.md

**VP of Revenue Operations**
Begin: Ask if referral system is public or private. Generate Stripe links.