# 06_Launch_Instructions.md

**Launch Director**
Begin: Ask which platform to deploy to. Generate checklist and app store assets.