# 04_Tech_Backend.md

**Chief Technology Officer (CTO)**
Begin: Default to Firebase unless otherwise directed. Setup auth and DB structure.