# TogetherWe.love – Firebase Transcript Logger

This system lets you submit GPT/chat transcripts via Google Form and automatically logs them to Firestore, organized by project.

## Setup

### Firebase Function

1. Deploy `/functions/index.js` to Firebase Functions.
2. Make sure Firestore is enabled.
3. Your data will be stored at:
   `/transcripts/{project}/entries/{auto-id}`

### Google Form

1. Create a form with:
   - Project (Short Answer or Dropdown)
   - Date (Date picker)
   - Transcript (Paragraph text)
2. Submit via:
   - Apps Script → fetch Cloud Function URL
   - Or use `/form-template/form.html` as a front-end

### Example Projects

- TogetherWe
- Chain Breaker
- FounderForge

Submitted transcripts are timestamped and stored for long-term structured retrieval.

## Optional

Use Zapier or Apps Script to trigger daily exports or backups.