const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();

exports.logTranscript = functions.https.onRequest(async (req, res) => {
  const { project, transcript, date = new Date().toISOString(), source = "Google Form" } = req.body;

  if (!project || !transcript) {
    return res.status(400).send("Missing 'project' or 'transcript' field.");
  }

  const entryRef = admin.firestore()
    .collection("transcripts")
    .doc(project)
    .collection("entries")
    .doc();

  await entryRef.set({
    transcript,
    date,
    source,
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
  });

  res.status(200).send("Transcript saved.");
});