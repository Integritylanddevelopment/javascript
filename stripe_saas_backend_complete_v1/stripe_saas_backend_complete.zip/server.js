// server.js
const express = require('express');
const app = express();
const admin = require('firebase-admin');
const serviceAccount = require('./firebase/firebaseServiceAccount.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

app.use(express.json());

// Middleware
const requireAuth = async (req, res, next) => {
  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).send('Missing auth token');
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    req.userId = decoded.uid;
    req.userEmail = decoded.email;
    req.customClaims = decoded;
    next();
  } catch (err) {
    return res.status(403).send('Invalid token');
  }
};

const rateLimiter = ({ featureKey, dailyLimit = 5 }) => {
  return async (req, res, next) => {
    const db = admin.firestore();
    const uid = req.userId;
    const today = new Date().toISOString().split('T')[0];
    const ref = db.collection('users').doc(uid);
    const doc = await ref.get();
    const used = doc.data()?.apiQuota?.[today]?.[featureKey] || 0;

    if (used >= dailyLimit) {
      await db.collection('abuseLogs').add({
        userId: uid,
        featureKey,
        timestamp: new Date().toISOString(),
        type: 'quota_exceeded'
      });
      return res.status(429).send('Daily quota exceeded');
    }

    await ref.set({
      apiQuota: {
        [today]: {
          [featureKey]: used + 1
        }
      }
    }, { merge: true });

    next();
  };
};

const requireAdmin = async (req, res, next) => {
  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).send('Missing token');
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    if (decoded.role === 'admin') {
      req.userId = decoded.uid;
      return next();
    }
    return res.status(403).send('Admins only');
  } catch (err) {
    return res.status(401).send('Invalid token');
  }
};

// Attach Routes
app.use('/api/get-user-data', (req, res) => res.send("get-user-data placeholder"));
app.use('/api/export-user-data', requireAuth, rateLimiter({ featureKey: 'export' }), (req, res) => res.send("export-user-data placeholder"));
app.use('/api/admin-dashboard-data', requireAdmin, (req, res) => res.send("admin-dashboard placeholder"));
app.use('/api/admin-analytics', requireAdmin, (req, res) => res.send("admin-analytics placeholder"));
app.use('/api/getCMSContent', (req, res) => res.send("getCMSContent placeholder"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
