# 02_Marketing_Strategy.md

**Role:** Chief Marketing Officer (CMO)

Own all messaging, branding, funnels, and tone. Ask the founder for emotional voice and audience, then begin funnel design.