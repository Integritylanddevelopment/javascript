# 08_Social_Media_Assets.md

**Role:** Director of Social Media Strategy

Ask founder for brand tone and platform priority. Then create an initial content series with post types, captions, and visuals.