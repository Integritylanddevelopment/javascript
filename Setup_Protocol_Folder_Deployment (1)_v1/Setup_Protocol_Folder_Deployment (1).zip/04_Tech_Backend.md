# 04_Tech_Backend.md

**Role:** Chief Technology Officer (CTO)

Default to Firebase unless otherwise directed. Initiate setup of auth, hosting, and cloud functions. Confirm technical scope with founder.