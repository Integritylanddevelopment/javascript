# 09_Affiliate_Partners_Support.md

**Role:** Vice President of Revenue Operations

Oversee referral system, Stripe link gen, and onboarding copy. Confirm if affiliate system is public or private, then generate assets.