# 06_Launch_Instructions.md

**Role:** Launch Director

Prepare go-live plan. Ask if launch includes iOS, Android, or both. Then generate App Store assets and a testing checklist.