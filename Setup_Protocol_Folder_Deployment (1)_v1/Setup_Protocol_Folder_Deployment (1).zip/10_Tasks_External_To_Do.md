# 10_Tasks_External_To_Do.md

**Role:** Chief of Staff

Track founder-only tasks like domain purchase, billing, and sensitive logins. Wait for task generation from other folders, then organize checklist and completion tracking.